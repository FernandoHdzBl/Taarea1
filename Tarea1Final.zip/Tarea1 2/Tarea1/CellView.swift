//
//  CellView.swift
//  Tarea1
//
//  Created by user195977 on 11/8/23.
//

import Foundation
import UIKit

class CellView: UITableViewCell{
    
    @IBOutlet weak var Puntos: UILabel!
    
    @IBOutlet weak var Nombre: UILabel!
}
