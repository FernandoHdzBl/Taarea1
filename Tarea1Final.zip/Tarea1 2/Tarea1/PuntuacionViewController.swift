//
//  PuntuacionViewController.swift
//  Tarea1
//
//  Created by user195977 on 11/8/23.
//

import UIKit

class PuntuacionViewController: UIViewController, UITableViewDataSource {

    @IBOutlet weak var ScoreText: UITextView!
    
    @IBOutlet weak var RankingTableView: UITableView!
        var PuntMax: [Ranking] = []
        let currentHighScore = UserDefaults.standard.integer(forKey: "ranking")
        var body = ""
        let url = URL(string: "https://api.restful-api.dev/objects")
        var ids: [String] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ScoreText.text = "Puntuacion: \(puntuacion)"
        ExtraerDatos()
    }
    

    @IBAction func GuardarDatos(_ sender: Any) {
        EnviarDatos()
    }
    
    func actualizarPuntuacion(nuevaPuntuacion: Int) {
            puntuacion = nuevaPuntuacion
           ScoreText.text = "\(puntuacion)"
        }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellView") as! CellView
        cell.Nombre.text = PuntMax[indexPath.row].Nombre
        cell.Puntos.text = PuntMax[indexPath.row].Puntuacion.description
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return PuntMax.count
    }
    
    func EnviarDatos(){
            var request = URLRequest(url: url!)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            let parameters: [String: Any] = [
                "name": Nombre,
                "data": [
                    "puntos": puntuacion,
                    "nombre": Nombre
                ]
            ]
            do {
                let jsonData = try JSONSerialization.data(withJSONObject: parameters, options: [])
                request.httpBody = jsonData
            } catch {
                print("Error: \(error)")
            }
            let task = URLSession.shared.dataTask(with: request) { data, response, error in
                if let error = error {
                    print("Error: \(error)")
                    return
                }
                
                if let data = data {
                    do {
                        let jsonResponse = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
                        let id = jsonResponse!["id"] as? String
                        self.ids.append(id!)
                        UserDefaults.standard.setValue(self.ids, forKey: "ids")
                        self.ExtraerDatos()
                        print("Response: \(String(describing: jsonResponse))")
                    } catch {
                        print("Error: \(error)")
                    }
                }
            }
            task.resume()
        }
    func ExtraerDatos(){
            let request = URL(string: GenerarURL())
            let task = URLSession.shared.dataTask(with: request!) { data, response, error in
                if let error = error {
                    print("Error: \(error)")
                    return
                }
                if let data = data {
                    do {
                        let jsonResponse = try JSONSerialization.jsonObject(with: data, options: [])
                        print("Response: \(jsonResponse)")
                        if let jsonArray = jsonResponse as? [[String: Any]] {
                            self.PuntMax.removeAll()
                            for puntuacion in jsonArray{
                                let nombre = puntuacion["nombre"] as? String
                                let datos = puntuacion["data"] as? [String: Any]
                                let puntos2 = datos?["puntos"] as? Int
                                let resultado = Ranking(puntos2!, nombre!)
                                self.PuntMax.append(resultado)
                                
                            }
                            DispatchQueue.main.async {
                                self.OrdenarDatos()
                                self.RankingTableView.reloadData()
                                
                            }
                        }
                    } catch {
                        print("Error: \(error)")
                    }
                }
            }
            task.resume()
        }
    
    func OrdenarDatos(){
            PuntMax.sort { (Resultado1, Resultado2) -> Bool in
                
                return Resultado1.Puntuacion > Resultado2.Puntuacion
            }
    }
    
    func GenerarURL() -> String {
        var url = "https://api.restful-api.dev/objects?"
        let idsArray = UserDefaults.standard.array(forKey: "ids") ?? []
        ids = idsArray as! [String]
        for id in ids {
            url += "id=" + id + "&"
        }
        url.removeLast()
        return url
    }
    
    
    

}
