//
//  RandomViewController.swift
//  Tarea1
//
//  Created by user195977 on 10/25/23.
//

import UIKit

var positions : [Int] = []
var puntuacion : Int = 0

class RandomViewController: UIViewController {
    
    
    @IBOutlet var Botones: [UIButton]!
    
    
    
    @IBOutlet weak var BotonComprobar: UIButton!
    
    var OrdenTocado : [Int] = []
    var currentIndex = 0
    var Images : [UIImage] = [UIImage(named: "Turquesa")!, UIImage(named: "Barco")!, UIImage(named: "Montaña")!, UIImage(named: "Arboles")!, UIImage(named: "puestaSol")!, UIImage(named: "Lago")!]

    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        for pulsador in Botones {
            pulsador.addTarget(self, action: #selector(BotonPulsado), for: .touchUpInside)
        }
        
        
        let positionArboles = numbersShuffle?.firstIndex(of: 0)
        let positionMontaña = numbersShuffle?.firstIndex(of: 1)
        let positionLago = numbersShuffle?.firstIndex(of: 2)
        let positionpuestaSol = numbersShuffle?.firstIndex(of: 3)
        let positionTurquesa = numbersShuffle?.firstIndex(of: 4)
        let positionBarco = numbersShuffle?.firstIndex(of: 5)
        positions = [positionArboles!, positionMontaña!, positionLago!, positionpuestaSol!, positionTurquesa!, positionBarco!]
        
        
    }
    func calcularResultado(){
        for i in 0..<OrdenTocado.count{
            if (OrdenTocado[i]) == (positions[i]){
                puntuacion += 100
            }
                       
        }
        UserDefaults.standard.setValue(puntuacion, forKey: "puntos")
        print(puntuacion)
            }
    
    @IBAction func BotonPulsado(_ sender: UIButton) {
        let indiceTocado = sender.tag
        OrdenTocado.append(indiceTocado)
        sender.imageView?.alpha = 0.5
        sender.isEnabled = false
        print(OrdenTocado)
        print(positions)
        if(OrdenTocado.count == 6){
            calcularResultado()
    }
        
    }
    
    @IBAction func Comprobar(_ sender: Any) {
        print(puntuacion)
        performSegue(withIdentifier: "Comprobar", sender: nil)
    }
    
}
