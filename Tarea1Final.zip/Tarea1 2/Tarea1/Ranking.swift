//
//  Ranking.swift
//  Tarea1
//
//  Created by user195977 on 11/9/23.
//

import Foundation

class Ranking {
    var Nombre: String
    var Puntuacion: Int
    
    init(_ score: Int, _ name: String) {
            self.Puntuacion = score
            self.Nombre = name
        }
}
