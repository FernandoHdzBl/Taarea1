//
//  ViewController.swift
//  Tarea1
//
//  Created by user195977 on 10/18/23.
//

import UIKit

var Nombre : String = ""

class ViewController: UIViewController {

    
    @IBOutlet weak var NombreTextView: UITextView!
    
    @IBAction func BotonInicio(_ sender: UIButton) {
        
        if let textoIngresado = NombreTextView.text, !textoIngresado.isEmpty {
                    Nombre = textoIngresado
                    print("Variable actualizada: \(Nombre)")
                } else {
                    print("Por favor, ingresa texto en el campo.")
                }
        UserDefaults.standard.setValue(Nombre, forKey: "nombre")
        performSegue(withIdentifier: "toGame", sender: nil)
    }
  
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
 
}

